from flask import Flask, jsonify, request
from flask_cors import CORS
import threading
import time
import cv2
import mediapipe as mp
import numpy as np
import joblib
import uuid

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Dictionary to manage multiple detection processes
detection_threads = {}
detection_data = {}

# Initialize mediapipe Pose Detection
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7,
    model_complexity=2
)

# Load the SVM model and scaler
model_filename = "svm_model_V3_1.pkl"
clf = joblib.load(model_filename)
scaler_filename = "scaler_V3_1.pkl"
scaler = joblib.load(scaler_filename)

# Load labels
label_file = "labels_V3.txt"
with open(label_file, 'r') as f:
    labels = f.readlines()
labels = [label.strip() for label in labels]

def compute_distances(landmarks):
    distances = []
    pairs = [(5, 2), (8, 7), (12, 11), (5, 8),
             (5, 7), (5, 0), (2, 7), (2, 8),
             (2, 0), (5, 11), (5, 12), (2, 11),
             (2, 12), (8, 11), (8, 12), (7, 11),
             (7, 12), (0, 8), (0, 7), (0, 11),
             (0, 12), (15, 9), (15, 10), (16, 9), (16, 10)]

    left_eye = landmarks.landmark[mp_pose.PoseLandmark.LEFT_EYE]
    right_eye = landmarks.landmark[mp_pose.PoseLandmark.RIGHT_EYE]
    eyes_center_x = int((left_eye.x + right_eye.x) / 2)
    eyes_center_y = int((left_eye.y + right_eye.y) / 2)
    nose_length = np.linalg.norm(np.array([eyes_center_x, eyes_center_y]) - np.array([landmarks.landmark[0].x, landmarks.landmark[0].y]))
    reference_pair = (12, 11)
    p_ref1 = np.array([landmarks.landmark[reference_pair[0]].x, landmarks.landmark[reference_pair[0]].y])
    p_ref2 = np.array([landmarks.landmark[reference_pair[1]].x, landmarks.landmark[reference_pair[1]].y])
    reference_distance = np.linalg.norm(p_ref1 - p_ref2)

    for pair in pairs:
        p1 = np.array([landmarks.landmark[pair[0]].x, landmarks.landmark[pair[0]].y])
        p2 = np.array([landmarks.landmark[pair[1]].x, landmarks.landmark[pair[1]].y])
        distance = np.linalg.norm(p1 - p2) / nose_length
        distances.append(distance)

    return distances

def run_pose_detection(session_id):
    global detection_data
    cap = cv2.VideoCapture(0)
    while session_id in detection_threads:
        ret, frame = cap.read()
        if not ret:
            break
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(rgb_frame)
        if results.pose_landmarks:
            landmarks = results.pose_landmarks
            distances = compute_distances(landmarks)
            distances = scaler.transform([distances])
            prediction = clf.predict(distances)
            confidence = np.max(clf.predict_proba(distances))
            label = labels[prediction[0]]
            detection_data[session_id] = {"label": label, "confidence": confidence}
            print(f"Session ID: {session_id}, Label: {label}, Confidence: {confidence}")
        time.sleep(1)  # Adjust the sleep duration as needed
    cap.release()
    # Clean up session data when detection stops
    detection_data.pop(session_id, None)

@app.route('/start-detection', methods=['POST'])
def start_detection():
    session_id = str(uuid.uuid4())  # Generate a unique session ID
    if session_id not in detection_threads:
        detection_threads[session_id] = threading.Thread(target=run_pose_detection, args=(session_id,))
        detection_threads[session_id].start()
        return jsonify({"session_id": session_id, "message": "Detection started"}), 200
    else:
        return jsonify({"message": "Detection already running"}), 400

@app.route('/stop-detection', methods=['POST'])
def stop_detection():
    session_id = request.json.get('session_id')
    if session_id in detection_threads:
        detection_threads[session_id] = None  # Signal the thread to stop
        del detection_threads[session_id]
        return jsonify({"message": "Detection stopped"}), 200
    return jsonify({"message": "Invalid session ID"}), 400

@app.route('/get-pose', methods=['GET'])
def get_pose():
    session_id = request.args.get('session_id')
    pose_data = detection_data.get(session_id, {"label": "N/A", "confidence": 0.0})
    print(f"Fetching pose data for session ID: {session_id}, Data: {pose_data}")  # Print to verify data
    return jsonify(pose_data), 200

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
