document.addEventListener('DOMContentLoaded', () => {
    // Function to fetch and display pose data
    function fetchPoseData() {
        chrome.storage.local.get(['poseData'], (result) => {
            const data = result.poseData || { label: 'N/A', confidence: 0.0 };
            console.log("Pose data fetched:", data);  // Print to verify data
            document.getElementById('poseLabel').textContent = data.label;
            document.getElementById('poseConfidence').textContent = data.confidence.toFixed(2);
        });
    }

    // Function to start pose detection
    function startDetection() {
        chrome.runtime.sendMessage({ action: 'startDetection' }, (response) => {
            console.log("Detection started:", response.message);
            fetchPoseData(); // Optionally fetch pose data after starting detection
        });
    }

    // Function to stop pose detection
    function stopDetection() {
        chrome.runtime.sendMessage({ action: 'stopDetection' }, (response) => {
            console.log("Detection stopped:", response.message);
        });
    }

    // Add event listeners to buttons
    document.getElementById('startBtn').addEventListener('click', startDetection);
    document.getElementById('stopBtn').addEventListener('click', stopDetection);

    // Fetch pose data every second (if needed)
    setInterval(fetchPoseData, 1000);  // Fetch pose data every 1 second (adjust as needed)
});
